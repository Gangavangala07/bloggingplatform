import React from 'react';
import { Link } from 'react-router-dom';
import './Footer.css';

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-container">

        {/* About Section */}
        <div className="footer-section about">
          <h4>About Our Blog</h4>
          <p>
            Welcome to our blogging platform where we share insightful articles, tips, and stories across a variety of topics. Join our community to stay informed and inspired.
          </p>
        </div>

        {/* Categories */}
        <div className="footer-section categories">
          <h4>Categories</h4>
          <ul>
            <li><Link to="/category/news">News</Link></li>
            <li><Link to="/category/tech">Tech</Link></li>
            <li><Link to="/category/lifestyle">Lifestyle</Link></li>
          </ul>
        </div>

        {/* Quick Links */}
        <div className="footer-section quick-links">
          <h4>Quick Links</h4>
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/about">About Us</Link></li>
            <li><Link to="/contact">Contact</Link></li>
          </ul>
        </div>

        {/* Newsletter */}
        <div className="footer-section newsletter">
          <h4>Newsletter</h4>
          <p>Subscribe for fresh articles, updates, and exclusive content straight to your inbox.</p>
          <input type="email" placeholder="Enter your email" />
          <button>Subscribe</button>
        </div>

      </div>
      <p className="footer-bottom">© 2025 YourBlogName. All rights reserved.</p>
    </footer>
  );
}

export default Footer;
