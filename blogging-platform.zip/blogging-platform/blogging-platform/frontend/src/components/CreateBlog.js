import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './CreateBlog.css';

const CreateBlog = () => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    if (!token) {
      alert('Please login first');
      navigate('/login');
      return;
    }
    if (!title.trim() || !content.trim()) {
      alert('Title and content are required');
      return;
    }
    try {
      await axios.post('http://localhost:5000/api/blogs', { title, content }, {
        headers: { 'x-auth-token': token }
      });
      alert('Blog created successfully!');
      navigate('/');
    } catch (error) {
      alert(error.response?.data?.message || 'Failed to create blog');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="blog-form">
      <h2 className="form-heading">Create Blog</h2>
      <input
        type="text"
        placeholder="Title"
        value={title}
        onChange={e => setTitle(e.target.value)}
        required
        className="form-input"
      />
      <textarea
        placeholder="Content"
        value={content}
        onChange={e => setContent(e.target.value)}
        rows={8}
        required
        className="form-textarea"
      />
      <button type="submit" className="form-button">Submit</button>
    </form>
  );
};

export default CreateBlog;
