import React, { useState } from 'react';
import axios from 'axios';
import Swal from 'sweetalert2';
import { useNavigate, Link } from 'react-router-dom';
import './Login.css';

function Login() {
  const [email, setEmail] = useState('');    
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);
    try {
      const response = await axios.post('http://localhost:5000/api/login', {
        email,
        password,
      });

      localStorage.setItem('token', response.data.token);
      localStorage.setItem('username', response.data.username);
      localStorage.setItem('isLoggedIn', 'true');

     Swal.fire({
  title: 'Registration Successful!',
  text: 'Please login to continue.',
  icon: 'success',
  confirmButtonText: 'OK',
  confirmButtonColor: '#00796b'
});


      navigate('/');
    } catch (error) {
      setErrorMsg(error.response?.data?.error || 'Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form
      onSubmit={handleLogin}
      className="login-form"
      aria-label="User login form"
      noValidate
    >
      <h2>User Login</h2>

      <input
        type="email"
        placeholder="Email"
        value={email}
        required
        onChange={(e) => setEmail(e.target.value)}
        className="login-input"
        aria-label="Email"
        autoComplete="email"
        disabled={loading}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        required
        onChange={(e) => setPassword(e.target.value)}
        className="login-input"
        aria-label="Password"
        autoComplete="current-password"
        disabled={loading}
      />

      <button
        type="submit"
        className="login-button"
        aria-label="Login button"
        disabled={loading}
      >
        {loading ? 'Logging in...' : 'Login'}
      </button>

      {errorMsg && (
        <div
          role="alert"
          aria-live="assertive"
          className="error-msg"
        >
          {errorMsg}
        </div>
      )}

      <div className="register-text">
        Don't have an account?
        <Link to="/register" className="register-link">
          Register
        </Link>
      </div>
    </form>
  );
}

export default Login;
