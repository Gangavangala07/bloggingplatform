import React, { useEffect, useState, useCallback } from 'react';
import axios from 'axios';
import './Profile.css';

function Profile() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [editBlogId, setEditBlogId] = useState(null);
  const [editContent, setEditContent] = useState('');
  const [error, setError] = useState(null);

  const token = localStorage.getItem('token');

  // Fetch user profile info + blogs, comments etc.
  const fetchProfile = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await axios.get('http://localhost:5000/api/profile', {
        headers: { 'x-auth-token': token },
      });
      setProfile(res.data);
    } catch (err) {
      setError('Failed to load profile');
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    fetchProfile();
  }, [fetchProfile]);

  // Delete blog - user-specific route
  const handleDeleteBlog = async (id) => {
    try {
    await axios.delete(`http://localhost:5000/api/blogs/user/${id}`, {
  headers: { 'x-auth-token': token }
});
 alert('Blog deleted!');
      fetchProfile();
    } catch (error) {
      console.error(error);
      alert('Failed to delete blog');
    }
  };

  // Edit blog (set editing state)
  const handleEditBlog = (id, currentContent) => {
    setEditBlogId(id);
    setEditContent(currentContent);
  };

  // Update blog content
  const handleUpdateBlog = async (id) => {
    if (!editContent.trim()) {
      alert('Content cannot be empty');
      return;
    }
    try {
      await axios.put(
        `http://localhost:5000/api/blogs/${id}`,
        { content: editContent },
        { headers: { 'x-auth-token': token } }
      );
      setEditBlogId(null);
      setEditContent('');
      fetchProfile();
    } catch (err) {
      alert('Failed to update blog');
      console.error(err);
    }
  };

  // Delete comment
  const handleDeleteComment = async (blogId, commentId) => {
    if (!window.confirm('Are you sure you want to delete this comment?')) return;
    try {
      await axios.delete(
        `http://localhost:5000/api/blogs/${blogId}/comments/${commentId}`,
        { headers: { 'x-auth-token': token } }
      );
      fetchProfile();
    } catch (err) {
      alert('Failed to delete comment');
      console.error(err);
    }
  };

  // Edit comment (prompt user)
  const handleEditComment = async (blogId, commentId, currentText) => {
    const updatedText = prompt('Edit your comment:', currentText);
    if (updatedText === null) return; // Cancelled
    if (!updatedText.trim()) {
      alert('Comment cannot be empty');
      return;
    }
    try {
      await axios.put(
        `http://localhost:5000/api/blogs/${blogId}/comments/${commentId}`,
        { text: updatedText },
        { headers: { 'x-auth-token': token } }
      );
      fetchProfile();
    } catch (err) {
      alert('Failed to update comment');
      console.error(err);
    }
  };

  // Unlike blog
  const handleUnlike = async (id) => {
    try {
      await axios.post(
        `http://localhost:5000/api/blogs/${id}/unlike`,
        {},
        { headers: { 'x-auth-token': token } }
      );
      fetchProfile();
    } catch (err) {
      alert('Failed to unlike blog');
      console.error(err);
    }
  };

  if (loading) return <div className="loading">Loading profile...</div>;
  if (error) return <div className="error">{error}</div>;
  if (!profile) return <div className="error">No profile data.</div>;

  return (
    <div className="profile-container">
      <div className="profile-card">
        <h2 className="profile-title">👤 User Profile</h2>
        <div className="profile-info">
          <p><strong>Username:</strong> {profile.username}</p>
          <p><strong>Email:</strong> {profile.email}</p>
        </div>
      </div>

      <div className="profile-section">
        <h3>📝 Blogs Published</h3>
        <ul>
          {profile.blogsPublished && profile.blogsPublished.length > 0 ? (
            profile.blogsPublished.map(blog => (
              <li key={blog._id}>
                <strong>{blog.title}</strong>
                {editBlogId === blog._id ? (
                  <div>
                    <textarea
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                      rows={4}
                      cols={50}
                    />
                    <button onClick={() => handleUpdateBlog(blog._id)}>Save</button>
                    <button onClick={() => setEditBlogId(null)}>Cancel</button>
                  </div>
                ) : (
                  <>
                    <p>{blog.content}</p>
                    <button onClick={() => handleEditBlog(blog._id, blog.content)}>Edit</button>
                    <button onClick={() => handleDeleteBlog(blog._id)}>Delete</button>
                  </>
                )}
              </li>
            ))
          ) : (
            <li>No blogs published yet.</li>
          )}
        </ul>
      </div>

      <div className="profile-section">
        <h3>👍 Blogs Liked</h3>
        <ul>
          {profile.blogsLiked && profile.blogsLiked.length > 0 ? (
            profile.blogsLiked.map(blog => (
              <li key={blog._id}>
                {blog.title}
                <button onClick={() => handleUnlike(blog._id)}>Unlike</button>
              </li>
            ))
          ) : (
            <li>No liked blogs.</li>
          )}
        </ul>
      </div>

      <div className="profile-section">
        <h3>💬 Comments Made</h3>
        <ul>
          {profile.commentsMade && profile.commentsMade.length > 0 ? (
            profile.commentsMade.map(blog => (
              <li key={blog._id}>
                <strong>{blog.title}</strong>
                <ul>
                  {blog.comments
                    .filter(c => c.userName === profile.username)
                    .map(comment => (
                      <li key={comment._id}>
                        {comment.text}{' '}
                        <button onClick={() => handleEditComment(blog._id, comment._id, comment.text)}>Edit</button>{' '}
                        <button onClick={() => handleDeleteComment(blog._id, comment._id)}>Delete</button>
                      </li>
                    ))}
                </ul>
              </li>
            ))
          ) : (
            <li>No comments made yet.</li>
          )}
        </ul>
      </div>
    </div>
  );
}

export default Profile;
