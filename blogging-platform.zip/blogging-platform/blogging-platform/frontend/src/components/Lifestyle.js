import React, { useState } from 'react';

function Lifestyle() {
  const dummyLifestyle = [
    {
      id: 1,
      title: "10-Minute Morning Yoga to Start Fresh",
      date: "May 21, 2025",
      excerpt: "Energize your body and mind with this quick yoga routine designed for busy mornings.",
      content: `This beginner-friendly sequence includes stretches, breathing exercises, and light poses aimed at waking up your muscles and boosting circulation. It helps in reducing stress and setting a positive tone for the day ahead.`
    },
    {
      id: 2,
      title: "Healthy Smoothie Recipes You’ll Love",
      date: "May 19, 2025",
      excerpt: "Blend your way to better health with these nutrient-packed smoothie ideas.",
      content: `From tropical mango-spinach blends to antioxidant-rich berry bowls, these smoothie recipes are easy to make, delicious, and loaded with vitamins. Perfect for breakfast or a post-workout snack.`
    },
  ];

  const [expandedIds, setExpandedIds] = useState([]);

  const toggleExpand = (id) => {
    if (expandedIds.includes(id)) {
      setExpandedIds(expandedIds.filter(expandedId => expandedId !== id));
    } else {
      setExpandedIds([...expandedIds, id]);
    }
  };

  return (
    <>
      <style>{`
        .app-container {
          max-width: 800px;
          margin: 40px auto;
          padding: 25px;
          background: #e0f7fa;
          border-radius: 20px;
          box-shadow: 0 8px 20px rgba(0, 150, 136, 0.3);
          font-family: 'Poppins', sans-serif;
          color: #222;
        }
        .page-title {
          font-size: 2.8rem;
          color: #006064;
          margin-bottom: 10px;
          text-align: center;
          font-weight: 700;
        }
        p {
          font-size: 1.15rem;
          margin-bottom: 30px;
          text-align: center;
          color: #4e4e4e;
        }
        .lifestyle-list {
          display: flex;
          flex-direction: column;
          gap: 30px;
        }
        .lifestyle-item {
          background: white;
          border-radius: 15px;
          padding: 20px 25px;
          box-shadow: 0 4px 15px rgba(0, 96, 100, 0.15);
          transition: transform 0.3s ease;
        }
        .lifestyle-item:hover {
          transform: translateY(-5px);
          box-shadow: 0 10px 30px rgba(0, 96, 100, 0.3);
        }
        .lifestyle-item h2 {
          color: #00796b;
          margin-bottom: 5px;
          font-weight: 700;
        }
        .lifestyle-item small {
          display: block;
          color: #78909c;
          margin-bottom: 15px;
          font-style: italic;
          font-weight: 500;
        }
        .lifestyle-item p {
          font-size: 1rem;
          line-height: 1.5;
          color: #37474f;
        }
        .lifestyle-full-content {
          white-space: pre-wrap;
          background-color: #e0f2f1;
          padding: 15px 18px;
          border-radius: 10px;
          margin-top: 15px;
          font-family: 'Courier New', Courier, monospace;
          font-size: 0.95rem;
          color: #004d40;
          line-height: 1.6;
        }
        .read-more-btn {
          margin-top: 18px;
          background-color: #00796b;
          color: white;
          border: none;
          padding: 10px 18px;
          border-radius: 12px;
          cursor: pointer;
          font-weight: 600;
          font-size: 1rem;
          transition: background-color 0.3s ease;
        }
        .read-more-btn:hover {
          background-color: #004d40;
        }
      `}</style>

      <div className="app-container">
        <h1 className="page-title">🌿 Lifestyle Tips</h1>
        <p>Healthy habits and mindful living inspiration.</p>

        <div className="lifestyle-list">
          {dummyLifestyle.map(item => (
            <div key={item.id} className="lifestyle-item">
              <h2>{item.title}</h2>
              <small>{item.date}</small>
              <p>{item.excerpt}</p>

              {expandedIds.includes(item.id) && (
                <pre className="lifestyle-full-content">{item.content}</pre>
              )}

              <button
                className="read-more-btn"
                onClick={() => toggleExpand(item.id)}
              >
                {expandedIds.includes(item.id) ? 'Show Less' : 'Read More'}
              </button>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

export default Lifestyle;
