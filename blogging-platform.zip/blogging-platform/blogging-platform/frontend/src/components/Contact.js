import React from 'react';
import './style.css';

function Contact() {
  return (
    <div className="page-container">
      <h1 className="page-title">📬 Contact the Blogger</h1>
      <p className="page-text">
        Have questions, feedback, or just want to say hello? Feel free to reach out!
      </p>
      <ul className="contact-list">
        <li>Email: blogger@example.com</li>
        <li>Twitter: @bloggerhandle</li>
        <li>Instagram: @bloggerhandle</li>
      </ul>
      <p className="page-text">Looking forward to connecting with you!</p>
    </div>
  );
}

export default Contact;
