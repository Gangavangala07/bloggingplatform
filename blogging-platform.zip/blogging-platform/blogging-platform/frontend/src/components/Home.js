import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const Home = () => {
  const [blogs, setBlogs] = useState([]);
  const token = localStorage.getItem('token');

  const fetchBlogs = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/blogs');
      setBlogs(res.data);
    } catch (err) {
      console.error('Error fetching blogs:', err);
    }
  };

  const handleLike = async (id) => {
    try {
      await axios.post(`http://localhost:5000/api/blogs/${id}/like`, {}, {
        headers: { 'x-auth-token': token }
      });
      fetchBlogs(); // refresh list after like
    } catch (err) {
      console.error('Error liking blog:', err);
    }
  };

  useEffect(() => {
    fetchBlogs();
  }, []);

  return (
    <div className="container">
      <h2 className="my-4">Latest Blogs</h2>
      {blogs.length === 0 ? (
        <p>No blogs available</p>
      ) : (
        blogs.map(blog => (
          <div key={blog._id} className="card mb-3">
            <div className="card-body">
              <h4>{blog.title}</h4>
              <p>{blog.content}</p>
              <p><strong>By:</strong> {blog.userName}</p>
              <p><strong>Likes:</strong> {blog.likes.length}</p>

              <button 
                onClick={() => handleLike(blog._id)} 
                className="btn btn-sm btn-outline-primary me-2"
              >
                Like
              </button>

              <Link to={`/blogs/${blog._id}`} className="btn btn-sm btn-outline-secondary">
                View & Comment
              </Link>
            </div>
          </div>
        ))
      )}
    </div>
  );
};

export default Home;
