const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

// MongoDB connection
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.log(err));

// User schema and model
const UserSchema = new mongoose.Schema({
  username: String,
  email: String,
  password: String
});
const User = mongoose.model("User", UserSchema);

// Blog schema and model
const BlogSchema = new mongoose.Schema({
  title: String,
  content: String,
  userName: String,
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  comments: [
    {
      text: String,
      userName: String,
      createdAt: { type: Date, default: Date.now },
    },
  ],
  likes: { type: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }], default: [] },
}, { timestamps: true });

const Blog = mongoose.model('Blog', BlogSchema);

// Admin schema and model
// Admin schema and model
const AdminSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  password: String,
});

const Admin = mongoose.model('Admin', AdminSchema);

// Auth middleware
const authMiddleware = (req, res, next) => {
  const token = req.headers['x-auth-token'];
  if (!token) return res.status(401).json({ error: "Unauthorized" });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    if (!req.user.role) req.user.role = 'user';
    return next();
  } catch (err) {
    return res.status(401).json({ error: "Invalid token" });
  }
};

const requireAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') return res.status(403).json({ message: 'Admins only' });
  next();
};

// User Registration
app.post('/api/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;
    if (!username || !email || !password) {
      return res.status(400).json({ error: 'Please fill all fields' });
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(400).json({ error: 'Email already registered' });

    const hash = await bcrypt.hash(password, 10);
    const user = new User({ username, email, password: hash });
    await user.save();

    return res.json({ message: 'Registered successfully' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error during registration' });
  }
});

// User Login
app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Please fill all fields' });
    }

    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ error: 'Invalid credentials' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ error: 'Invalid credentials' });

    const token = jwt.sign(
      { id: user._id, username: user.username, role: 'user' },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    return res.json({ token, username: user.username });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error during login' });
  }
});

// Admin Registration
app.post('/api/admins/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;
    if (!username || !email || !password) {
      return res.status(400).json({ error: 'Please fill all fields' });
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(400).json({ error: 'Email already registered' });

    const hash = await bcrypt.hash(password, 10);
    const user = new User({ username, email, password: hash });
    await user.save();

    return res.json({ message: 'Registered successfully' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error during registration' });
  }
});

// Admin Login
app.post('/api/admins/login', async (req, res) => {
   try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Please fill all fields' });
    }

    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ error: 'Invalid credentials' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ error: 'Invalid credentials' });

    const token = jwt.sign(
      { id: user._id, username: user.username, role: 'user' },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    return res.json({ token, username: user.username });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error during login' });
  }
});
// Get All Blogs
app.get('/api/blogs', async (req, res) => {
  try {
    // Optional: populate user info if you want
    const blogs = await Blog.find()
      .populate('userId', 'username email')
      .sort({ createdAt: -1 });
    return res.json(blogs);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error fetching blogs' });
  }
});

// Get blog by ID

app.get('/api/blogs/:id', async (req, res) => {
  const { id } = req.params;
  
  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({ error: 'Invalid blog ID format' });
  }

  try {
    const blog = await Blog.findById(id);
    if (!blog) return res.status(404).json({ error: 'Blog not found' });
    res.json(blog);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Create Blog
app.post('/api/blogs', authMiddleware, async (req, res) => {
  try {
    const { title, content } = req.body;
    if (!title || !content) {
      return res.status(400).json({ error: 'Title and content required' });
    }

    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const newBlog = new Blog({
      title,
      content,
      userName: user.username,
      userId: user._id,
    });

    await newBlog.save();
    return res.status(201).json(newBlog);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error creating blog' });
  }
});

// Like Blog
app.post('/api/blogs/:id/like', authMiddleware, async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ msg: 'Blog not found' });

    const userIdStr = req.user.id.toString();
    if (blog.likes.some(userId => userId.toString() === userIdStr)) {
      return res.status(400).json({ msg: 'Already liked' });
    }

    blog.likes.push(req.user.id);
    await blog.save();
    return res.json(blog);
  } catch (error) {
    console.error(error);
    return res.status(500).send('Server error');
  }
});

// Comment on Blog
app.post('/api/blogs/:id/comment', authMiddleware, async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) return res.status(400).json({ error: 'Comment text required' });

    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ error: 'Blog not found' });

    blog.comments.push({
      text,
      userName: user.username,
    });
    await blog.save();

    return res.status(200).json(blog);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error adding comment' });
  }
});

// Edit Blog
app.put('/api/blogs/:id/edit', authMiddleware, async (req, res) => {
  try {
    const { title, content } = req.body;
    if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ message: 'Invalid blog ID' });
    }

    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ message: 'Blog not found' });

    if (req.user.role === 'admin' || blog.userId.toString() === req.user.id) {
      if (title) blog.title = title;
      if (content) blog.content = content;
      // Clean likes just in case
      blog.likes = blog.likes.filter(like => mongoose.Types.ObjectId.isValid(like));
      await blog.save();
      return res.json(blog);
    } else {
      return res.status(403).json({ message: 'Not authorized' });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Server error' });
  }
});

// Delete Blog (Admins only)
app.delete('/api/blogs/:id', authMiddleware, requireAdmin, async (req, res) => {
  try {
    const blog = await Blog.findByIdAndDelete(req.params.id);
    if (!blog) return res.status(404).json({ message: 'Blog not found' });
    return res.json({ message: 'Blog deleted' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error' });
  }
});

// Admin blog delete by ID (without auth - can be improved for security)
app.delete('/api/admins/blogs/:id', async (req, res) => {
  try {
    const deleted = await Blog.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: 'Blog not found' });
    return res.json({ message: 'Deleted successfully' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error' });
  }
});

// Profile Route - Get user and their blogs
app.get('/api/profile', authMiddleware, async (req, res) => {
  try {
    const username = req.user.username;

    // Find the user without password
    const user = await User.findOne({ username }).select('-password');
    if (!user) return res.status(404).json({ error: 'User not found' });

    // Blogs published by this user (match userName field)
    const blogsPublished = await Blog.find({ userName: username }).sort({ createdAt: -1 });

    // Blogs liked by this user (likes array contains user's ObjectId)
    const blogsLiked = await Blog.find({ likes: user._id }).sort({ createdAt: -1 });

    // Blogs where user commented (comments.userName equals username)
    const commentsMade = await Blog.find({ 'comments.userName': username }).sort({ createdAt: -1 });

    return res.json({
      username: user.username,
      email: user.email,
      blogsPublished,
      blogsLiked,
      commentsMade
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/blogs/:blogId/comments/:commentId', authMiddleware, async (req, res) => {

  const blog = await Blog.findById(req.params.blogId);
  if (!blog) return res.status(404).json({ message: 'Blog not found' });

  blog.comments = blog.comments.filter(c => c._id.toString() !== req.params.commentId);
  await blog.save();
  res.json({ message: 'Comment deleted' });
});

app.put('/api/blogs/:id', authMiddleware, async (req, res) => {
  try {
    const { title, content } = req.body;
    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ msg: 'Blog not found' });

    if (blog.userId.toString() !== req.user.id) {
      return res.status(403).json({ msg: 'Unauthorized to edit this blog' });
    }

    blog.title = title || blog.title;
    blog.content = content || blog.content;
    await blog.save();

    res.json(blog);
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

app.delete('/api/blogs/user/:id', authMiddleware, async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog) {
      return res.status(404).json({ message: 'Blog not found' });
    }
    if (blog.userId.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Unauthorized' });
    }
    await blog.deleteOne();
    res.json({ message: 'Blog deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});


app.put('/api/blogs/:blogId/comments/:commentId', authMiddleware, async (req, res) => {
  try {
    const { blogId, commentId } = req.params;
    const { text } = req.body;
    const blog = await Blog.findById(blogId);
    if (!blog) return res.status(404).json({ msg: 'Blog not found' });

    const comment = blog.comments.id(commentId);
    if (!comment) return res.status(404).json({ msg: 'Comment not found' });

    if (comment.userName !== req.user.username) {
      return res.status(403).json({ msg: 'Unauthorized to edit this comment' });
    }

    comment.text = text;
    await blog.save();
    res.json({ msg: 'Comment updated' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

app.post('/api/blogs/:id/unlike', authMiddleware, async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ msg: 'Blog not found' });

    blog.likes = blog.likes.filter(userId => userId.toString() !== req.user.id);
    await blog.save();

    res.json({ msg: 'Blog unliked' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});



const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

